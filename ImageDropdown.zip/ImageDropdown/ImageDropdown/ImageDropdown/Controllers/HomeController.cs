﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ImageDropdown.Models;

namespace ImageDropdown.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            List<Country> cntry=new List<Country>();
           // cntry.Add()
           Country ind=new Country();
            ind.Name = "India";
            ind.ID = 1;
           
            ind.URL = "~/Images/IND.png";
            cntry.Add(ind);

            Country us = new Country();
            us.Name = "USA";
            us.ID = 2;
            us.URL = "~/Images/IND.png";
            cntry.Add(us);

            return View(cntry);
        }

    }
   
}
